'use client';

import ManageBrandsCategoriesClient from '@/components/ManageBrandsCategoriesClient';

export default function ManageBrandsCategoriesPage() {
  return <ManageBrandsCategoriesClient initialCategories={[]} initialBrands={[]} />;
}
