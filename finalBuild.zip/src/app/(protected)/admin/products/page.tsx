'use client';

import ManageProductsClient from '@/components/ManageProductsClient';

export default function ManageProductsPage() {
  return <ManageProductsClient initialProducts={[]} initialCategories={[]} initialBrands={[]} />;
}
