import AddProductClientPage from './AddProductClientPage';

export default function AddProductPage() {
  return <AddProductClientPage />;
}
