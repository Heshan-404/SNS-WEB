'use client';

import * as VisuallyHiddenPrimitive from '@radix-ui/react-visually-hidden';

const VisuallyHidden = VisuallyHiddenPrimitive.Root;

export { VisuallyHidden };
